<div class="" style="margin-top:90px;text-align:center;background:#42a5f5 ">
  <div class="row" style="margin-top:70px;margin:50px auto;display: inline-block;">
    <div class="input_form">
      <form class="" action="#" method="post">
        <h6 style="color:#fff">Subcribe To Our Newslater</h6>
        <div class="row" style="background:#fff;border-radius:50px;padding:5px;height:45px">
          <div class="col s8">
            <input type="text" name="" value="" style="width:100%;border:none;font-size:14px;margin-top:-5px;margin-left:10px" placeholder="Enter your email">
          </div>
          <div class="col s1">
            <input type="submit" value="Subcribe" style="border-radius: 20px;border: none;height: 40px;width:102px;background:#42a5f5;color: #fff;margin-top: -3px;">
          </div>
        </div>
      </form>
    </div>
  </div>
</div>
