<div class="" style="margin-top:90px;margin-bottom:30px;text-align:center">
  <h5 style="font-weight:800">Why Choose Us?</h5>
  <div class="row" style="margin-top:70px;margin:50px auto;display: inline-block;">
    <div class="col s3" style="width:300px">
      <div class="chooseHeader">
        <i class="material-icons" style="background:#42a5f5 ;color:#fff;padding:10px;border-radius:10px;">content_paste</i>
        <h6 style="font-weight:800;padding-top:10px;">Travel Partner</h6>
        <p style="text-align:justify;font-size:12px;padding-left:20px; padding-right:20px">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p>
      </div>
    </div>

    <div class="col s3" style="width:300px">
      <div class="chooseHeader">
        <i class="material-icons" style="background:#42a5f5 ;color:#fff;padding:10px;border-radius:10px;">attach_money</i>
        <h6 style="font-weight:800;padding-top:10px;">Chep Rates</h6>
        <p style="text-align:justify;font-size:12px;padding-left:20px; padding-right:20px">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p>
      </div>
    </div>

    <div class="col s3" style="width:300px">
      <div class="chooseHeader">
        <i class="material-icons" style="background:#42a5f5 ;color:#fff;padding:10px;border-radius:10px;">chat_bubble_outline</i>
        <h6 style="font-weight:800;padding-top:10px;">Good Service</h6>
        <p style="text-align:justify;font-size:12px;padding-left:20px; padding-right:20px">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p>
      </div>
    </div>
  </div>
  <div class="row" style="margin:50px auto;display: inline-block;">
    <div class="col s3" style="width:300px">
      <div class="chooseHeader">
        <i class="material-icons" style="background:#42a5f5 ;color:#fff;padding:10px;border-radius:10px;">book</i>
        <h6 style="font-weight:800;padding-top:10px;">Easy To Book</h6>
        <p style="text-align:justify;font-size:12px;padding-left:20px; padding-right:20px">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p>
      </div>
    </div>

    <div class="col s3" style="width:300px">
      <div class="chooseHeader">
        <i class="material-icons" style="background:#42a5f5 ;color:#fff;padding:10px;border-radius:10px;">person_add</i>
        <h6 style="font-weight:800;padding-top:10px;">Experince Guide</h6>
        <p style="text-align:justify;font-size:12px;padding-left:20px; padding-right:20px">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p>
      </div>
    </div>

    <div class="col s3" style="width:300px">
      <div class="chooseHeader">
        <i class="material-icons" style="background:#42a5f5 ;color:#fff;padding:10px;border-radius:10px;">photo_camera</i>
        <h6 style="font-weight:800;padding-top:10px;">Full Documentation</h6>
        <p style="text-align:justify;font-size:12px;padding-left:20px; padding-right:20px">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p>
      </div>
    </div>
  </div>
</div>
