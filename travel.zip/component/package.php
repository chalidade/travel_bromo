<div class="tour-package" style="text-align:center;margin-top:50px">
  <h5 style="font-weight:800">Popular Tour Packages</h5>
  <div class="row" style="margin-top:70px;">
    <div class="col s2"> </div>
    <div class="col s2" style="border-radius:10px;">
      <div class="package" style="box-shadow: 5px 7px 5px #dcdcdc40;border-radius:10px">
        <div class="fotoPaket" style="height:250px;border-top-left-radius: 10px;border-top-right-radius: 10px;background:url('img/gunung_bromo2.jpg');background-size:cover"></div>
        <div class="deskripsiPaket" style="padding:2px">
          <p style="font-weight:800">Borobudur Temple</p>
          <table style="margin-top:-20px">
            <tr style="font-size:10px;border:none">
              <td><i class="material-icons" style="color:orange;font-size:14px">star</i></td>
              <td>4,5</td>
              <td><i class="material-icons" style="color:gray;font-size:14px">people</i></td>
              <td>5 People</td>
              <td>IDR</td>
              <td><font style="font-weight: 800;">500K</font></td>
            </tr>
          </table>
        </div>
      </div>
    </div>
    <div class="col s2">
      <div class="package" style="box-shadow: 5px 7px 5px #dcdcdc40;border-radius:10px">
        <div class="fotoPaket" style="height:250px;border-top-left-radius: 10px;border-top-right-radius: 10px;background:url('img/gunung_bromo2.jpg');background-size:cover"></div>
        <div class="deskripsiPaket" style="padding:2px">
          <p style="font-weight:800">Borobudur Temple</p>
          <table style="margin-top:-20px">
            <tr style="font-size:10px;border:none">
              <td><i class="material-icons" style="color:orange;font-size:14px">star</i></td>
              <td>4,5</td>
              <td><i class="material-icons" style="color:gray;font-size:14px">people</i></td>
              <td>5 People</td>
              <td>IDR</td>
              <td><font style="font-weight: 800;">500K</font></td>
            </tr>
          </table>
        </div>
      </div>
    </div>
    <div class="col s2">
      <div class="package" style="box-shadow: 5px 7px 5px #dcdcdc40;border-radius:10px">
        <div class="fotoPaket" style="height:250px;border-top-left-radius: 10px;border-top-right-radius: 10px;background:url('img/gunung_bromo2.jpg');background-size:cover"></div>
        <div class="deskripsiPaket" style="padding:2px">
          <p style="font-weight:800">Borobudur Temple</p>
          <table style="margin-top:-20px">
            <tr style="font-size:10px;border:none">
              <td><i class="material-icons" style="color:orange;font-size:14px">star</i></td>
              <td>4,5</td>
              <td><i class="material-icons" style="color:gray;font-size:14px">people</i></td>
              <td>5 People</td>
              <td>IDR</td>
              <td><font style="font-weight: 800;">500K</font></td>
            </tr>
          </table>
        </div>
      </div>
    </div>
    <div class="col s2">
      <div class="package" style="box-shadow: 5px 7px 5px #dcdcdc40;border-radius:10px">
        <div class="fotoPaket" style="height:250px;border-top-left-radius: 10px;border-top-right-radius: 10px;background:url('img/gunung_bromo2.jpg');background-size:cover"></div>
        <div class="deskripsiPaket" style="padding:2px">
          <p style="font-weight:800">Borobudur Temple</p>
          <table style="margin-top:-20px">
            <tr style="font-size:10px;border:none">
              <td><i class="material-icons" style="color:orange;font-size:14px">star</i></td>
              <td>4,5</td>
              <td><i class="material-icons" style="color:gray;font-size:14px">people</i></td>
              <td>5 People</td>
              <td>IDR</td>
              <td><font style="font-weight: 800;">500K</font></td>
            </tr>
          </table>
        </div>
      </div>
    </div>
    <div class="col s2"></div>
  </div>
  <center><button class="btn light-blue lighten-1" style="height: 35px;border-radius:20px;font-size:10px;text-transform:Capitalize;width:140px;margin-top:15px">View All</button></center>
</div>
